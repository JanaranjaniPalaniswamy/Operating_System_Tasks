#include <stdio.h> // printf()
#include <unistd.h> // sleep(), getpid(), getppid()
#include <signal.h> // SIGCHLD flag
#include <linux/sched.h> // CLONE flags
#include <stdio.h>

void printids(char *str) {
  printf("TGID: %d of %s \n", getpid(),str); // Print the TGID of the current process
  printf("PPID: %d of %s \n", getppid(),str); // Print the PPID of the current process  
  printf("\n\n");
  sleep(1);
}
int child(char *str) 
{
  printids(str);
}


int main(void)
{
 int pid = getpid();
void *pchild_stack = malloc(1024 * 1024);
  // TODO Implement:
char *str = "Clone";
// 1 fork() and 1 clone() to create a process //
	fork();
	clone(child, pchild_stack + (1024*1024),SIGCHLD,str);
	// 1 clone() that creates a new thread //
  	clone(child, pchild_stack + (1024*1024),CLONE_VM | CLONE_FS | CLONE_FILES | CLONE_SYSVSEM
                       | CLONE_SIGHAND | CLONE_THREAD
                       | CLONE_SETTLS | CLONE_PARENT_SETTID
                       | CLONE_CHILD_CLEARTID
                       | 0,str);
char *s;
if(getpid()==pid)
	s = "Main";
else
	s = "Fork";
printids(s); // IDs of the main process 

sleep(1000);

return 0;
}

